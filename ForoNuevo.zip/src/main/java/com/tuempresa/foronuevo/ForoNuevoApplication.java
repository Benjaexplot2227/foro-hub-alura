package com.tuempresa.foronuevo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ForoNuevoApplication {
    public static void main(String[] args) {
        SpringApplication.run(ForoNuevoApplication.class, args);
    }
}