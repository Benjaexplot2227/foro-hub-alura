package com.tuempresa.foronuevo.controller;

import org.springframework.web.bind.annotation.*;
import org.springframework.http.ResponseEntity;
import org.springframework.beans.factory.annotation.Autowired;
import java.util.List;
import com.tuempresa.foronuevo.domain.topico.*;

@RestController
@RequestMapping("/topicos")
public class TopicoController {

    @Autowired
    private TopicoRepository topicoRepository;

    @PostMapping
    public ResponseEntity<Void> registrar(@RequestBody DatosRegistroTopico datos) {
        Topico topico = new Topico(datos);
        topicoRepository.save(topico);
        return ResponseEntity.ok().build();
    }

    @GetMapping
    public ResponseEntity<List<DatosDetalleTopico>> listar() {
        var lista = topicoRepository.findAll().stream().map(DatosDetalleTopico::new).toList();
        return ResponseEntity.ok(lista);
    }
}