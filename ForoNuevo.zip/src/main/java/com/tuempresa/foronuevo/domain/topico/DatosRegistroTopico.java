package com.tuempresa.foronuevo.domain.topico;

public record DatosRegistroTopico(String titulo, String mensaje) {}