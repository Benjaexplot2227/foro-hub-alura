package com.tuempresa.foronuevo.domain.topico;

public record DatosDetalleTopico(String titulo, String mensaje) {
    public DatosDetalleTopico(Topico topico) {
        this(topico.getTitulo(), topico.getMensaje());
    }
}