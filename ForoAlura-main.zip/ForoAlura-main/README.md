# Challenge Foro Hub

<p>
La practica consiste en una aplicacion en consola que su proposito inicial es el inicio de sesion para poder utilizar las funcionalidades de un CRUD, donde se Registra un topico, dicho topico, puede ser Consultado, Modificado y Eliminado, mediante una base de datos guardar los datos y consultarlos desde dicha base de datos, la cual esta creada en Mysql
</p>

>[!NOTE] 
>Es una practica por lo que aun puede contener algunos errores.

>[!TIP] 
>Realiza el registro de un usuario desde la base de datos

>[!IMPORTANT] 
>Se requiere de inicio de sesion para obtener un token 

**<p> La practica se realiza con fines de apredizaje en el cual se trata de poner en practica distintos temas vistos a lo largo del curso</p>**
## Algunos temas que se utilizaron para realizar la practica

- Programacion Orientada a objetos
- Uso de librerias
- Spring Security
- Spring Data JPA
- Bearer Token

## Tecnologias Utilizadas
- Java
- Mysql
