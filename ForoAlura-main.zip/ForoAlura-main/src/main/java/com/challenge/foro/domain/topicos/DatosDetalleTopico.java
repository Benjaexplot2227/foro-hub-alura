package com.challenge.foro.domain.topicos;

public record DatosDetalleTopico(

        String mensaje,
        String nombreCurso,
        String titulo
) {

public DatosDetalleTopico(Topico topico){

    this(topico.getMensaje(),
            topico.getNombreCurso(),
            topico.getTitulo());

}


}
