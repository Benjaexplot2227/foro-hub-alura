package com.challenge.foro.infra.security;

public record DatosTokenJWT(String token) {
}
