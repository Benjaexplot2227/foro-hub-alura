package com.challenge.foro.domain.topicos;

import jakarta.validation.constraints.NotNull;

public record DatosActualizarTopico(

        @NotNull long id,
        String mensaje,
        String nombreCurso,
        String titulo
) {
}
