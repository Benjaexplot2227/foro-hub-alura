package com.challenge.foro.domain.topicos;

import com.challenge.foro.domain.usuario.Usuario;

public record DatosListarTopico(
        String mensaje,
        String nombreCurso,
        String titulo) {


    public DatosListarTopico(Topico topico) {

        this(topico.getMensaje(),
                topico.getNombreCurso(),
                topico.getTitulo());

    }
}
