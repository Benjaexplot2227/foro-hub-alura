package com.challenge.foro.domain.topicos;

import com.challenge.foro.domain.usuario.Usuario;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Table(name ="topicos")
@Entity(name="Topico")
@Getter
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(of="id")
public class Topico {
@Id
@GeneratedValue(strategy = GenerationType.IDENTITY)
private Long id;

private String mensaje;
private String nombreCurso;
private String titulo;

public Topico(DatosRegistrarTopico topico){

this.mensaje=topico.mensaje();
this.nombreCurso=topico.nombreCurso();
this.titulo=topico.titulo();

}

public void actualizarTopico(DatosActualizarTopico topico){

    if (topico.mensaje() != null) {
        this.mensaje = topico.mensaje();
    }
    if (topico.nombreCurso() != null) {
        this.nombreCurso = topico.nombreCurso();
    }
    if (topico.titulo() != null) {
        this.titulo = topico.titulo();
    }
}

}
