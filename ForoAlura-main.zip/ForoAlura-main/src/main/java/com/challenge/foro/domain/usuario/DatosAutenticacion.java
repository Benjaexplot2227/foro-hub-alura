package com.challenge.foro.domain.usuario;

public record DatosAutenticacion(
        String login,
        String contrasena
) {
}
