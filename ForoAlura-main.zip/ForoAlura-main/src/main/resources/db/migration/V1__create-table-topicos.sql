create table topicos(

id bigint not null auto_increment,
mensaje varchar(255) not null,
nombre_curso varchar(255) not null,
titulo varchar(255) not null,

primary key(id)
);
