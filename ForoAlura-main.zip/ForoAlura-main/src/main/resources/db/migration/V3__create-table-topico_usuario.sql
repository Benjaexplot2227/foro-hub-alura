create table topico_usuario(

id bigint not null auto_increment,
topicos_id bigint not null,
usuario_id bigint not null,
fecha datetime not null,

primary key(id),
constraint fk_topico_usuario_topicos_id foreign key(topicos_id) references topicos(id),
constraint fk_topico_usuario_usuario_id foreign key(usuario_id) references usuarios(id)
);